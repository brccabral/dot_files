<template>
  <h1>Hello World</h1>
</template>

<script>
export default {};
</script>

<style>
html {
  font-family: sans-serif;
}
</style>