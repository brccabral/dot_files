# Vue Starter

## Project Setup
```sh
npm install # install initial packages
npm install vite-plugin-eslint --save-dev # install dev dependencies
npm run dev # runs in dev mode
npm run build # builds app for production
```
